<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/firststyle.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <style>
        .scrollable-col {
            max-height: 35px;
            overflow-y: auto;
        }

        .list-group-item {
            height: 59px;
        }

        .fa-trash-alt {
            color: red;
        }

        .fa-edit {
            color: green;
        }
    </style>
    <div id="konteynir">
        <div class="row">
            <div class="col-md" id="baslik"><h1>Index</h1></div>
            <div class="col-md"><a href="<?php echo e(route('employees.create')); ?>" class="btn btn-success float-right">Tambah
                    Employee</a></div>
        </div>
        <ul class="list-group">

            
            
            
            
            
            
            
            <li class="list-group-item">
                <?php echo e(Form::open(['route' => 'employees.index', 'method' => 'GET'])); ?>

                <div class="row justify-content-between">
                    <div class="col-md-1">
                    </div>
                    <div class="col-md">
                        <?php echo e(Form::text('namefilter', request('namefilter') , ['class' => 'form-control', 'placeholder' => 'Name Filter'])); ?>

                    </div>
                    <div class="col-md">
                        <?php echo e(Form::text('lastnamefilter', request('lastnamefilter'), ['class' => 'form-control', 'placeholder' => 'Lastname Filter'])); ?>

                    </div>
                    <div class="col-md">
                        <?php echo e(Form::text('emailfilter', request('emailfilter'), ['class' => 'form-control', 'placeholder' => 'E-mail Filter'])); ?>

                    </div>
                    <div class="col-md">
                        <?php echo e(Form::text('phonefilter', request('phonefilter') , ['class' => 'form-control', 'placeholder' => 'Phone Filter'])); ?>

                    </div>
                    <div class="col-md">
                        <?php echo e(Form::select('companyfilter', $company_names, request('companyfilter'), ['class' => 'form-control', 'placeholder' => 'All'])); ?>

                    </div>
                    <div class="col-md-2">
                        <?php echo e(Form::submit('Filter', ['class' => 'btn btn-success my-2 my-sm-0'])); ?>

                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </li>
            <li class="list-group-item">
                <div class="row justify-content-between">
                    <div class="col-md-1">Id</div>
                    <div class="col-md">Name</div>
                    <div class="col-md">Lastname</div>
                    <div class="col-md">E-mail</div>
                    <div class="col-md">Phone</div>
                    <div class="col-md">Company</div>
                    <div class="col-md-1">Edit</div>
                    <div class="col-md-1">Delete</div>
                </div>
            </li>
            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-md-1 scrollable-col">
                            <?php echo e($employee->id); ?>

                        </div>
                        <div class="col-md scrollable-col">
                            <?php echo e($employee->name); ?>

                        </div>
                        <div class="col-md scrollable-col">
                            <?php echo e($employee->lastname); ?>

                        </div>
                        <div class="col-md scrollable-col">
                            <a href="mailto:<?php echo e($employee->email); ?>"><?php echo e($employee->email); ?></a>
                        </div>
                        <div class="col-md scrollable-col">
                            <?php echo e($employee->phone); ?>

                        </div>
                        <div class="col-md scrollable-col">
                            <?php echo e($employee->company->name); ?>

                        </div>
                        <div class="col-md-1">
                            <a href="<?php echo e(route('employees.edit', $employee)); ?>"><i class="far fa-edit"></i></a>
                        </div>
                        <div class="col-md-1">
                            <?php echo e(Form::open([ 'method' => 'delete', 'route' => ['employees.destroy', $employee]])); ?>

                            <?php echo e(Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => ''])); ?>

                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <div style="padding-top: 16px"> <?php echo e($employees->links()); ?> </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>