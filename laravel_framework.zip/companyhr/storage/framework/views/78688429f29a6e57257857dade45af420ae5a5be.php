<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/firststyle.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .scrollable-col {
            max-height: 35px;
            overflow-y: auto;
        }

        .list-group-item {
            height: 59px;
        }

        .fa-trash-alt {
            color: red;
        }

        .fa-edit {
            color: green;
        }
    </style>
    <div id="konteynir">
        
        <div class="row">
            <div class="col-md" id="baslik"><h1>Index</h1></div>
            <div class="col-md"><a href="<?php echo e(url('companies/create')); ?>" class="btn btn-success float-right">Tambah Company</a></div>
        </div>
        <?php if(count($companies)): ?>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            <ul class="list-group">
                <li class="list-group-item">
                    <?php echo e(Form::open(['route' => 'companies.index', 'method' => 'GET'])); ?>

                    <div class="row justify-content-between">
                        <div class="col-md-1">
                        </div>
                        <div class="col-md">
                            <?php echo e(Form::text('namefilter', request('namefilter') , ['class' => 'form-control', 'placeholder' => 'Name Filter'])); ?>

                        </div>
                        <div class="col-md">
                            <?php echo e(Form::text('addressfilter', request('addressfilter'), ['class' => 'form-control', 'placeholder' => 'Address Filter'])); ?>

                        </div>
                        <div class="col-md">
                            <?php echo e(Form::text('phonefilter', request('phonefilter'), ['class' => 'form-control', 'placeholder' => 'Phone Filter'])); ?>

                        </div>
                        <div class="col-md">
                            <?php echo e(Form::text('emailfilter', request('emailfilter') , ['class' => 'form-control', 'placeholder' => 'E-mail Filter'])); ?>

                        </div>
                        <div class="col-md">
                            <?php echo e(Form::text('websitefilter', request('websitefilter'), ['class' => 'form-control', 'placeholder' => 'Website Filter'])); ?>

                        </div>
                        <div class="col-md-2">
                            <?php echo e(Form::submit('Filter', ['class' => 'btn btn-success my-2 my-sm-0'])); ?>

                            <button class="btn btn-danger">Export</button>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </li>
                <li class="list-group-item">
                    <div class="row justify-content-between">
                        <div class="col-md-1">Id</div>
                        <div class="col-md">Name</div>
                        <div class="col-md">Address</div>
                        <div class="col-md">Phone</div>
                        <div class="col-md">E-mail</div>
                        <div class="col-md">Website</div>
                        <div class="col-md-1">Edit</div>
                        <div class="col-md-1">Delete</div>
                    </div>
                </li>
                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <div class="row">
                            <div class="col-md-1 scrollable-col">
                                <?php echo e($company->id); ?>

                            </div>
                            <div class="col-md scrollable-col">
                                <a href="<?php echo e(route('companies.show', $company)); ?>"><?php echo e($company->name); ?></a>
                            </div>
                            <div class="col-md scrollable-col">
                                <?php echo e($company->address); ?>

                            </div>
                            <div class="col-md scrollable-col">
                                <?php echo e($company->phone); ?>

                            </div>
                            <div class="col-md scrollable-col">
                                <a href="mailto:<?php echo e($company->email); ?>"><?php echo e($company->email); ?></a>
                            </div>
                            <div class="col-md scrollable-col">
                                <a href="http://<?php echo e($company->website); ?>"><?php echo e($company->website); ?></a>
                            </div>
                            <div class="col-md-1"><a href="<?php echo e(route('companies.edit', $company)); ?>"><i
                                            class="far fa-edit"></i></a></div>
                            <div class="col-md-1">
                                <?php echo e(Form::open([ 'method' => 'delete', 'route' => ['companies.destroy', $company]])); ?>

                                <?php echo e(Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => ''])); ?>

                                <?php echo e(Form::close()); ?>

                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>

            <p>You don't have any Company!</p>

        <?php endif; ?>
        <div style="padding-top: 16px"> <?php echo e($companies->links()); ?> </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>