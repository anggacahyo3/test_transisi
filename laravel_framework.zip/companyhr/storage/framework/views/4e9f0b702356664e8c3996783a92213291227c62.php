<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/firststyle.css")); ?>" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card" style="">
                    <div class="card-body">

                        <?php echo e(Form::model($employee, ['route' => $route, 'method' => $method])); ?>


                        <div class="form-group row yeni">
                            <?php echo e(Form::label('name', 'Name: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('name')): ?>
                                <div class="btn btn-danger">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('lastname', 'Last Name: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('lastname', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('lastname')): ?>
                                <div class="btn btn-danger">
                                    <?php echo e($errors->first('lastname')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('email', 'E-Mail Address: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('email')): ?>
                                <div class="btn btn-danger">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('phone', 'Telephone Number: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

                            </div>
                            <?php if($errors->has('phone')): ?>
                                <div class="btn btn-danger">
                                    <?php echo e($errors->first('phone')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('companyid', 'Company: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::select('companyid', $company_names,null,['class' => 'form-control'])); ?>

                            </div>
                        </div>

                        <div class="form-group row yeni">
                            <div class="col-sm-3">
                            </div>
                            <div class="col-sm-6">
                                <?php echo e(Form::submit('Save changes', ['class' => 'btn btn-success'])); ?>

                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>