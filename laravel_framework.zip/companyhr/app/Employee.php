<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;


class Employee extends Model
{
    protected $fillable = [
        'name',
        'lastname',
        'phone',
        'email',
        'companyid',
        'logo',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class, 'companyid');
    }

    public static function get_query(Request $request)
    {
        return Employee::with('company')
            ->when($request->filled('namefilter'), function ($query) use ($request) {
                $query->where('name', 'LIKE', "%{$request->input('namefilter')}%");
            })
            ->when($request->filled('lastnamefilter'), function ($query) use ($request) {
                $query->where('lastname', 'LIKE', "%{$request->input('lastnamefilter')}%");
            })
            ->when($request->filled('emailfilter'), function ($query) use ($request) {
                $query->where('email', 'LIKE', "%{$request->input('emailfilter')}%");
            })
            ->when($request->filled('phonefilter'), function ($query) use ($request) {
                $query->where('phone', 'LIKE', "%{$request->input('phonefilter')}%");
            })
            ->when($request->filled('companyfilter'), function ($query) use ($request) {
                $query->where('companyid', "{$request->input('companyfilter')}");
            });
    }
}
