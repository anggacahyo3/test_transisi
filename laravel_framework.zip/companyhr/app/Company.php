<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Company extends Model
{
    protected $fillable = [
        'name',
        'address',
        'phone',
        'email',
        'website',
        'logo',
    ];
    protected $attributes = [
        'logo' => 'noimg.png',
    ];

    public function employees()
    {
        return $this->hasMany(Employee::class,'companyid');
    }

}
