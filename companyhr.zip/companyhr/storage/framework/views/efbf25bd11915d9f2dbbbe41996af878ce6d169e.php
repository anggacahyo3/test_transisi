<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset("css/firststyle.css")); ?>" >
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card" style="">

                    <?php if($company->exists): ?>
                    <img class="card-img-top" src="<?php echo e(asset('company_logos/'.$company->logo)); ?>"
                         alt="<?php echo e($company->logo.' logo'); ?>">
                    <h1 class="text-center">Edit <?php echo e($company->name); ?></h1>
                    <?php else: ?>
                        <h1 class="text-center">Create New Company</h1>
                    <?php endif; ?>

                    
                    
                    
                    
                    

                    
                    

                    <div class="card-body">

                        <?php echo e(Form::model($company, ['route' => $route, 'files' => true, 'method' => $method])); ?>


                        <div class="form-group row yeni">
                            <?php echo e(Form::label('name', 'Name: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('name')): ?>
                                <div class="btn btn-danger col-sm-3">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('email', 'E-Mail Address: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('email')): ?>
                                <div class="btn btn-danger col-sm-3">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('phone', 'Telephone Number: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('phone', null, ['class' => 'form-control'])); ?>

                            </div>
                        </div>


                        <div class="form-group row yeni">
                            <?php echo e(Form::label('website', 'Web Site: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::text('website', null, ['class' => 'form-control'])); ?>

                            </div>
                        </div>

                        <div class="form-group row yeni">
                            <?php echo e(Form::label('address', 'Address: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::textarea('address', null, ['class' => 'form-control'])); ?>

                            </div>
                            
                            <?php if($errors->has('address')): ?>
                                <div class="alert alert-danger col-sm-3">
                                    <?php echo e($errors->first('address')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        


                        <div class="form-group row yeni">
                            <?php echo e(Form::label('logo', 'Company Logo: ', ['class' => 'col-sm-3 col-form-label'])); ?>

                            <div class="col-sm-6">
                                <?php echo e(Form::file('logo')); ?>

                            </div>
                            
                            <?php if($errors->has('logo')): ?>
                                <div class="alert alert-danger col-sm-3">
                                    <?php echo e($errors->first('logo')); ?>

                                </div>
                            <?php endif; ?>
                        </div>


                        <div class="form-group row yeni">
                            <div class="col-sm-3">
                            </div>
                            <div class="col-sm-6">
                                <?php echo e(Form::submit('Save Company', ['class' => 'btn btn-success'])); ?>

                            </div>
                        </div>
                        <?php echo e(Form::close()); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>